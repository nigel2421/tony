<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>错误信息</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0" />
	<meta name="apple-mobile-web-app-capable" content="yes" />
</head>
<body>


<div style="margin-left:10%;margin-top:5%;">
    <div style="margin-bottom:20px;"><img src="/core/template/face02.png" height="120"></div>
    <div style="font-size:20px;margin-bottom:20px;">您访问路径含有非法字符，防注入系统提醒您请勿尝试非法操作！ <span id="time" style="font-size:18px;"></span></div>
    <div><span style="font-size:12px;border-top:1px solid #ccc;color:#ccc;padding-top:2px;">
   		程序版本：3.2.1-20220921
    </span></div>
</div>



</body>
</html>